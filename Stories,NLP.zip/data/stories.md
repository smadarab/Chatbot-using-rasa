## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese", "location": "delhi"}
    - slot{"cuisine": "chinese"}
    - slot{"location": "delhi"}
    - utter_ask_budget
* ask_budget{"budget": "701"}
    - slot{"budget": "701"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "Yes"}
    - slot{"mailconfirmation": "Yes"}
    - action_decide_email
* ask_email{"email": "wfeiwhfi.com"}
    - slot{"email": "wfeiwhfi.com"}
    - action_decide_email
* ask_email{"email": "upgradchatbotassignment@gmail.com"}
    - slot{"email": "upgradchatbotassignment@gmail.com"}
    - action_send_email
    - reset_slots
    - utter_goodbye

## interactive_story_1
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "bangalore"}
    - slot{"location": "bangalore"}
    - action_check_city
    - slot{"location": "Bangalore"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "italian"}
    - slot{"cuisine": "italian"}
    - action_validate_cuisine
    - slot{"cuisine": "Italian"}
    - utter_ask_budget
* ask_budget{"budget": "300-700"}
    - slot{"budget": "300-700"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "yes", "email": "upgradchatbotassingment@gmail.com"}
    - slot{"email": "upgradchatbotassingment@gmail.com"}
    - slot{"mailconfirmation": "yes"}
    - action_decide_email
    - action_send_email
    - reset_slots

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"location": "rishikesh"}
    - slot{"location": "rishikesh"}
    - action_check_city
    - slot{"location": null}
* restaurant_search{"location": "allahabad"}
    - slot{"location": "allahabad"}
    - action_check_city
    - slot{"location": null}
* restaurant_search{"location": "chennai"}
    - slot{"location": "chennai"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_validate_cuisine
    - slot{"cuisine": "Chinese"}
    - utter_ask_budget
* ask_budget{"budget": "700"}
    - slot{"budget": "700"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "yes", "email": "upgradchatbotassignment@gmail.com"}
    - slot{"email": "upgradchatbotassignment@gmail.com"}
    - slot{"mailconfirmation": "yes"}
    - action_decide_email
    - action_send_email
    - reset_slots

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"location": "kolkata"}
    - slot{"location": "kolkata"}
    - action_check_city
    - slot{"location": "Kolkata"}
    - utter_ask_cuisine
* ask_cuisine{"cuisine": " American"}
    - slot{"cuisine": " American"}
    - utter_ask_budget
* ask_budget{"budget": "300"}
    - slot{"budget": "300"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "yes"}
    - slot{"mailconfirmation": "yes"}
    - action_decide_email
* ask_email{"email": "upgradchatbotassignment@gmail.com"}
    - slot{"email": "upgradchatbotassignment@gmail.com"}
    - action_send_email
    - reset_slots

## interactive_story_1
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* ask-location{"location": "mubaim"}
    - slot{"location": "mubaim"}
    - action_check_city
    - slot{"location": null}
* restaurant_search{"location": "Mumbai"}
    - slot{"location": "Mumbai"}
    - action_check_city
    - slot{"location": "Mumbai"}
    - utter_ask_cuisine
* ask_cuisine{"cuisine": " American"}
    - slot{"cuisine": " American"}
    - action_validate_cuisine
    - slot{"cuisine": "American"}
    - utter_ask_budget
* ask_budget{"budget": "300"}
    - slot{"budget": "300"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "yes"}
    - slot{"mailconfirmation": "yes"}
    - action_decide_email
* ask_email{"email": "me.com"}
    - slot{"email": "me.com"}
    - action_decide_email
* ask_email{"email": "upgradchatbotassignment@gmail.com"}
    - slot{"email": "upgradchatbotassignment@gmail.com"}
    - action_send_email
    - reset_slots
    - utter_goodbye

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese", "location": "chandigarh"}
    - slot{"cuisine": "chinese"}
    - slot{"location": "chandigarh"}
    - action_check_city
    - slot{"location": "Chandigarh"}
    - action_validate_cuisine
    - slot{"cuisine": "Chinese"}
    - utter_ask_budget
* ask_budget{"budget": "299"}
    - slot{"budget": "299"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "no"}
    - slot{"mailconfirmation": "no"}
    - action_decide_email
    - slot{"email": null}
    - utter_goodbye
    - action_restart

## interactive_story_1
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* ask-location{"location": "krosur"}
    - slot{"location": "krosur"}
    - action_check_city
    - slot{"location": null}
* ask-location{"location": "nashik"}
    - slot{"location": "nashik"}
    - action_check_city
    - slot{"location": "Nashik"}
    - utter_ask_cuisine
* ask_cuisine{"cuisine": "latin"}
    - slot{"cuisine": "latin"}
    - action_validate_cuisine
    - slot{"cuisine": null}
    - utter_ask_cuisine
* ask_cuisine{"cuisine": " American"}
    - slot{"cuisine": " American"}
    - action_validate_cuisine
    - utter_ask_budget
* ask_budget{"budget": "701"}
    - slot{"budget": "701"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "No"}
    - slot{"mailconfirmation": "No"}
    - action_decide_email
    - reset_slots

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"cuisine": " American"}
    - slot{"cuisine": " American"}
    - action_validate_cuisine
    - slot{"cuisine": "American"}
    - utter_ask_location
* ask-location{"location": "ongole"}
    - slot{"location": "ongole"}
    - action_check_city
    - slot{"location": null}
* ask-location{"location": "miryalguda"}
    - slot{"location": "miryalguda"}
    - action_check_city
    - slot{"location": null}
* ask-location{"location": "khammam"}
    - slot{"location": "khammam"}
    - action_check_city
    - slot{"location": null}
* restaurant_search{"location": "indore"}
    - slot{"location": "indore"}
    - action_check_city
    - slot{"location": "Indore"}
    - utter_ask_budget
* ask_budget{"budget": "299"}
    - slot{"budget": "299"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "Yes"}
    - slot{"mailconfirmation": "Yes"}
    - action_decide_email
* ask_email{"email": "upgradchatbotassignment@gmail.com"}
    - slot{"email": "upgradchatbotassignment@gmail.com"}
    - action_send_email
    - reset_slots

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"location": "delhi"}
    - slot{"location": "delhi"}
    - action_check_city
    - slot{"location": "Delhi"}
    - utter_ask_cuisine
* ask_cuisine{"cuisine": "Italian"}
    - slot{"cuisine": "Italian"}
    - action_validate_cuisine
    - slot{"cuisine": "Italian"}
    - utter_ask_budget
* ask_budget{"budget": "700"}
    - slot{"budget": "700"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "please", "email": "upgradchatbotassignment@gmail.com"}
    - slot{"email": "upgradchatbotassignment@gmail.com"}
    - slot{"mailconfirmation": "please"}
    - action_decide_email
    - action_send_email
    - reset_slots

## interactive_story_1
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* ask-location{"location": "vasai-virar city"}
    - slot{"location": "vasai-virar city"}
    - action_check_city
    - slot{"location": "Vasai-Virar City"}
    - utter_ask_cuisine
* ask_cuisine{"cuisine": "thai"}
    - slot{"cuisine": "thai"}
    - action_validate_cuisine
    - slot{"cuisine": null}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "South Indian"}
    - slot{"cuisine": "South Indian"}
    - action_validate_cuisine
    - slot{"cuisine": "South Indian"}
    - utter_ask_budget
* ask_budget{"budget": "1000"}
    - slot{"budget": "1000"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "all right"}
    - slot{"mailconfirmation": "all right"}
    - action_decide_email
* ask_email{"email": "upgradchatbotassignment@gmail.com"}
    - slot{"email": "upgradchatbotassignment@gmail.com"}
    - action_send_email
    - reset_slots

## interactive_story_3
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* ask-location{"location": "bombay"}
    - slot{"location": "bombay"}
    - action_check_city
    - slot{"location": "Bombay"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "South Indian"}
    - slot{"cuisine": "South Indian"}
    - action_validate_cuisine
    - slot{"cuisine": "South Indian"}
    - utter_ask_budget
* ask_budget{"budget": "700"}
    - slot{"budget": "700"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "please"}
    - slot{"mailconfirmation": "please"}
    - action_decide_email
* ask_email{"email": "upgradchatbotassignment@gmail.com"}
    - slot{"email": "upgradchatbotassignment@gmail.com"}
    - action_send_email
    - reset_slots

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"location": "kolkata"}
    - slot{"location": "kolkata"}
    - action_check_city
    - slot{"location": "Kolkata"}
    - utter_ask_cuisine
* ask_cuisine{"cuisine": "southafrican"}
    - slot{"cuisine": "southafrican"}
    - action_validate_cuisine
    - slot{"cuisine": null}
    - utter_ask_cuisine
* ask_cuisine{"cuisine": "Italian"}
    - slot{"cuisine": "Italian"}
    - action_validate_cuisine
    - slot{"cuisine": "Italian"}
    - utter_ask_budget
* ask_budget{"budget": "100"}
    - slot{"budget": "100"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "no"}
    - slot{"mailconfirmation": "no"}
    - action_decide_email
    - reset_slots

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"location": "khammam"}
    - slot{"location": "khammam"}
    - action_check_city
    - slot{"location": null}
* ask-location{"location": "nagarjuna sagar"}
    - slot{"location": "nagarjuna sagar"}
    - action_check_city
    - slot{"location": null}
* restaurant_search{"location": "guntur"}
    - slot{"location": "guntur"}
    - action_check_city
    - slot{"location": "Guntur"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "Italian"}
    - slot{"cuisine": "Italian"}
    - action_validate_cuisine
    - slot{"cuisine": "Italian"}
    - utter_ask_budget
* ask_budget{"budget": "600 - 900"}
    - slot{"budget": "600 - 900"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "dont"}
    - slot{"mailconfirmation": "dont"}
    - action_decide_email
    - reset_slots

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"location": "chennai"}
    - slot{"location": "chennai"}
    - action_check_city
    - slot{"location": "Chennai"}
    - utter_ask_cuisine
* ask_cuisine{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - action_validate_cuisine
    - slot{"cuisine": "North Indian"}
    - utter_ask_budget
* ask_budget{"budget": "800 and 900"}
    - slot{"budget": "800 and 900"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "aye aye"}
    - slot{"mailconfirmation": "aye aye"}
    - action_decide_email
* ask_email{"email": "upgradchatbotassingment@gmail.com"}
    - slot{"email": "upgradchatbotassingment@gmail.com"}
    - action_send_email
    - reset_slots

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"location": "Chennai"}
    - slot{"location": "Chennai"}
    - action_check_city
    - slot{"location": "Chennai"}
    - utter_ask_cuisine
* ask_cuisine{"cuisine": "south asian"}
    - slot{"cuisine": "south asian"}
    - action_validate_cuisine
    - slot{"cuisine": null}
    - utter_ask_cuisine
* ask_cuisine{"cuisine": "North Indian"}
    - slot{"cuisine": "North Indian"}
    - action_validate_cuisine
    - slot{"cuisine": "North Indian"}
    - utter_ask_budget
* ask_budget{"budget": "300,400"}
    - slot{"budget": "300,400"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "No"}
    - slot{"mailconfirmation": "No"}
    - action_decide_email
    - reset_slots

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"location": "Delhi"}
    - slot{"location": "Delhi"}
    - action_check_city
    - slot{"location": "Delhi"}
    - utter_ask_cuisine
* ask_cuisine{"cuisine": "North Indian"}
    - slot{"cuisine": "North Indian"}
    - action_validate_cuisine
    - slot{"cuisine": "North Indian"}
    - utter_ask_budget
* ask_budget{"budget": "300"}
    - slot{"budget": "300"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "Yes"}
    - slot{"mailconfirmation": "Yes"}
    - action_decide_email
* ask_email{"email": "ifweif.com"}
    - slot{"email": "ifweif.com"}
    - action_send_email
    - action_send_email

## interactive_story_2
* greet
    - utter_greet
* restaurant_search{"location": "delhi"}
    - slot{"location": "delhi"}
    - action_check_city
    - slot{"location": "Delhi"}
    - utter_ask_cuisine
* ask_cuisine{"cuisine": " American"}
    - slot{"cuisine": " American"}
    - action_validate_cuisine
    - slot{"cuisine": "American"}
    - utter_ask_budget
* ask_budget{"budget": "701"}
    - slot{"budget": "701"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "Yes"}
    - slot{"mailconfirmation": "Yes"}
    - action_decide_email
* ask_email{"email": "wfewfe.com"}
    - slot{"email": "wfewfe.com"}
    - action_send_email
* ask_email{"email": "upgradchatbotassignment@gmail.com"}
    - slot{"email": "upgradchatbotassignment@gmail.com"}
    - action_send_email
    - reset_slots

## interactive_story_1
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "GWALIOR"}
    - slot{"location": "GWALIOR"}
    - action_check_city
    - slot{"location": "Gwalior"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "romanian"}
    - slot{"cuisine": "romanian"}
    - action_validate_cuisine
    - slot{"cuisine": null}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "Italian"}
    - slot{"cuisine": "Italian"}
    - action_validate_cuisine
    - slot{"cuisine": "Italian"}
    - utter_ask_budget
* restaurant_search{"budget": "500"}
    - slot{"budget": "500"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "Yes"}
    - slot{"mailconfirmation": "Yes"}
    - action_decide_email
* ask_email{"email": "fwiefweif.com"}
    - slot{"email": "fwiefweif.com"}
    - action_send_email
* ask_email{"email": "upgradchatbotassignment@gmail.com"}
    - slot{"email": "upgradchatbotassignment@gmail.com"}
    - action_send_email
    - reset_slots

## interactive_story_1
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* ask-location{"location": "hubli-dharwad"}
    - slot{"location": "hubli-dharwad"}
    - action_check_city
    - slot{"location": null}
* restaurant_search{"location": "moradabad"}
    - slot{"location": "moradabad"}
    - action_check_city
    - slot{"location": "Moradabad"}
    - utter_ask_cuisine
* ask_cuisine{"cuisine": "thai"}
    - slot{"cuisine": "thai"}
    - action_validate_cuisine
    - slot{"cuisine": null}
    - utter_ask_cuisine
* ask_cuisine{"cuisine": " American"}
    - slot{"cuisine": " American"}
    - action_validate_cuisine
    - slot{"cuisine": "American"}
    - utter_ask_budget
* ask_budget{"budget": "299"}
    - slot{"budget": "299"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "No"}
    - slot{"mailconfirmation": "No"}
    - action_decide_email
    - reset_slots

## interactive_story_2
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* ask-location{"location": "hubli-dharwad"}
    - slot{"location": "hubli-dharwad"}
    - action_check_city
    - slot{"location": null}
* restaurant_search{"location": "jodhpur"}
    - slot{"location": "jodhpur"}
    - action_check_city
    - slot{"location": "Jodhpur"}
    - utter_ask_cuisine
* ask_cuisine{"cuisine": " American"}
    - slot{"cuisine": " American"}
    - action_validate_cuisine
    - slot{"cuisine": "American"}
    - utter_ask_budget
* ask_budget{"budget": "701"}
    - slot{"budget": "701"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "Yes"}
    - slot{"mailconfirmation": "Yes"}
    - action_decide_email
* ask_email{"email": "upgradchatbotassignment@gmail.com"}
    - slot{"email": "upgradchatbotassignment@gmail.com"}
    - action_send_email
    - reset_slots

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"location": "jaipur"}
    - slot{"location": "jaipur"}
    - action_check_city
    - slot{"location": "Jaipur"}
    - utter_ask_cuisine
* ask_cuisine{"cuisine": "japanese"}
    - slot{"cuisine": "japanese"}
    - action_validate_cuisine
    - slot{"cuisine": null}
    - utter_ask_cuisine
* ask_cuisine{"cuisine": "thai"}
    - slot{"cuisine": "thai"}
    - action_validate_cuisine
    - slot{"cuisine": null}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "Italian"}
    - slot{"cuisine": "Italian"}
    - action_validate_cuisine
    - slot{"cuisine": "Italian"}
    - utter_ask_budget
* ask_budget{"budget": "701"}
    - slot{"budget": "701"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "allright", "email": "upgradchatbotassignment@gmail.com"}
    - slot{"email": "upgradchatbotassignment@gmail.com"}
    - slot{"mailconfirmation": "allright"}
    - action_decide_email
    - action_send_email
    - reset_slots

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"location": "cuttack"}
    - slot{"location": "cuttack"}
    - action_check_city
    - slot{"location": "Cuttack"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "South Indian"}
    - slot{"cuisine": "South Indian"}
    - action_validate_cuisine
    - slot{"cuisine": "South Indian"}
    - utter_ask_budget
* restaurant_search{"budget": "400 and 900"}
    - slot{"budget": "400 and 900"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "send", "email": "fiwefw.com"}
    - slot{"email": "fiwefw.com"}
    - slot{"mailconfirmation": "send"}
    - action_decide_email
* ask_email{"email": "fnwefnew.com"}
    - slot{"email": "fnwefnew.com"}
    - action_send_email
* ask_email{"email": "upgradchatbotassignment@gmail.com"}
    - slot{"email": "upgradchatbotassignment@gmail.com"}
    - action_send_email
    - reset_slots

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"cuisine": " Mexican", "location": "Delhi"}
    - slot{"cuisine": " Mexican"}
    - slot{"location": "Delhi"}
    - action_check_city
    - slot{"location": "Delhi"}
    - action_validate_cuisine
    - slot{"cuisine": "Mexican"}
    - utter_ask_budget
* restaurant_search{"budget": "400 and 900"}
    - slot{"budget": "400 and 900"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "send"}
    - slot{"mailconfirmation": "send"}
    - action_decide_email
* ask_email{"email": "uwefwe.com"}
    - slot{"email": "uwefwe.com"}
    - action_send_email
* ask_email{"email": "upgradchatbotassignment@gmail.com"}
    - slot{"email": "upgradchatbotassignment@gmail.com"}
    - action_send_email
    - reset_slots

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"cuisine": "southindian", "location": "pune"}
    - slot{"cuisine": "southindian"}
    - slot{"location": "pune"}
    - action_check_city
    - slot{"location": "Pune"}
    - action_validate_cuisine
    - slot{"cuisine": null}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "Italian"}
    - slot{"cuisine": "Italian"}
    - action_validate_cuisine
    - slot{"cuisine": "Italian"}
    - utter_ask_budget
* ask_budget{"budget": "701"}
    - slot{"budget": "701"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "No"}
    - slot{"mailconfirmation": "No"}
    - action_decide_email
    - reset_slots

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"cuisine": " American", "location": "bareilly"}
    - slot{"cuisine": " American"}
    - slot{"location": "bareilly"}
    - action_check_city
    - slot{"location": "Bareilly"}
    - action_validate_cuisine
    - slot{"cuisine": "American"}
    - utter_ask_budget
* ask_budget{"budget": "700"}
    - slot{"budget": "700"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "No"}
    - slot{"mailconfirmation": "No"}
    - action_decide_email
    - reset_slots

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"location": "aurangabad"}
    - slot{"location": "aurangabad"}
    - action_check_city
    - slot{"location": "Aurangabad"}
    - utter_ask_cuisine
* ask_cuisine{"cuisine": " Mexican"}
    - slot{"cuisine": " Mexican"}
    - action_validate_cuisine
    - slot{"cuisine": "Mexican"}
    - utter_ask_budget
* ask_budget{"budget": "701"}
    - slot{"budget": "701"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "Yes"}
    - slot{"mailconfirmation": "Yes"}
    - action_decide_email
* ask_email{"email": "upgradchatbotassignment@gmail.com"}
    - slot{"email": "upgradchatbotassignment@gmail.com"}
    - action_send_email
    - reset_slots

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"cuisine": " American"}
    - slot{"cuisine": " American"}
    - action_validate_cuisine
    - slot{"cuisine": "American"}
    - utter_ask_location
* ask-location{"location": "coimbatore"}
    - slot{"location": "coimbatore"}
    - action_check_city
    - slot{"location": "Coimbatore"}
    - utter_ask_budget
* ask_budget{"budget": "700"}
    - slot{"budget": "700"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "sure"}
    - slot{"mailconfirmation": "sure"}
    - action_decide_email
* ask_email{"email": "upgradchatbotassignment@gmail.com"}
    - slot{"email": "upgradchatbotassignment@gmail.com"}
    - action_send_email
    - reset_slots

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"location": "ajmer"}
    - slot{"location": "ajmer"}
    - action_check_city
    - slot{"location": "Ajmer"}
    - utter_ask_cuisine
* ask_cuisine{"cuisine": " Mexican"}
    - slot{"cuisine": " Mexican"}
    - action_validate_cuisine
    - slot{"cuisine": "Mexican"}
    - utter_ask_budget
* ask_budget{"budget": "299"}
    - slot{"budget": "299"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "No"}
    - slot{"mailconfirmation": "No"}
    - action_decide_email
    - reset_slots

## interactive_story_1
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "kanpur"}
    - slot{"location": "kanpur"}
    - action_check_city
    - slot{"location": "Kanpur"}
    - utter_ask_cuisine
* ask_cuisine{"cuisine": "North Indian"}
    - slot{"cuisine": "North Indian"}
    - action_validate_cuisine
    - slot{"cuisine": "North Indian"}
    - utter_ask_budget
* ask_budget{"budget": "800"}
    - slot{"budget": "800"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "No"}
    - slot{"mailconfirmation": "No"}
    - action_decide_email
    - reset_slots

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"location": "sompur"}
    - slot{"location": "sompur"}
    - action_check_city
    - slot{"location": null}
* restaurant_search{"location": "solapur"}
    - slot{"location": "solapur"}
    - action_check_city
    - slot{"location": "Solapur"}
    - utter_ask_cuisine
* ask_cuisine{"cuisine": " Mexican"}
    - slot{"cuisine": " Mexican"}
    - action_validate_cuisine
    - slot{"cuisine": "Mexican"}
    - utter_ask_budget
* ask_budget{"budget": "701"}
    - slot{"budget": "701"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "Yes"}
    - slot{"mailconfirmation": "Yes"}
    - action_decide_email
* ask_email{"email": "upgradchatbotassignment@gmail.com"}
    - slot{"email": "upgradchatbotassignment@gmail.com"}
    - action_send_email
    - reset_slots

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"location": "meerut"}
    - slot{"location": "meerut"}
    - action_check_city
    - slot{"location": "Meerut"}
    - utter_ask_cuisine
* ask_cuisine{"cuisine": "North Indian"}
    - slot{"cuisine": "North Indian"}
    - action_validate_cuisine
    - slot{"cuisine": "North Indian"}
    - utter_ask_budget
* ask_budget{"budget": "700"}
    - slot{"budget": "700"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "Yes"}
    - slot{"mailconfirmation": "Yes"}
    - action_decide_email
* ask_email{"email": "upgradchatbotassignment@gmail.com"}
    - slot{"email": "upgradchatbotassignment@gmail.com"}
    - action_send_email
    - reset_slots

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"location": "cohci"}
    - slot{"location": "cohci"}
    - action_check_city
    - slot{"location": null}
* restaurant_search{"location": "kochi"}
    - slot{"location": "kochi"}
    - action_check_city
    - slot{"location": "Kochi"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "South Indian"}
    - slot{"cuisine": "South Indian"}
    - action_validate_cuisine
    - slot{"cuisine": "South Indian"}
    - utter_ask_budget
* ask_budget{"budget": "299"}
    - slot{"budget": "299"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "send", "email": "upgradchatbotassignment@gmail.com"}
    - slot{"email": "upgradchatbotassignment@gmail.com"}
    - slot{"mailconfirmation": "send"}
    - action_decide_email
    - action_send_email
    - reset_slots

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"location": "bilaspur"}
    - slot{"location": "bilaspur"}
    - action_check_city
    - slot{"location": "Bilaspur"}
    - utter_ask_cuisine
* ask_cuisine{"cuisine": " American"}
    - slot{"cuisine": " American"}
    - action_validate_cuisine
    - slot{"cuisine": "American"}
    - utter_ask_budget
* ask_budget{"budget": "900"}
    - slot{"budget": "900"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "No"}
    - slot{"mailconfirmation": "No"}
    - action_decide_email
    - reset_slots

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"location": "bijapur"}
    - slot{"location": "bijapur"}
    - action_check_city
    - slot{"location": "Bijapur"}
    - utter_ask_cuisine
* ask_cuisine{"cuisine": "spanish"}
    - slot{"cuisine": "spanish"}
    - action_validate_cuisine
    - slot{"cuisine": null}
    - utter_ask_cuisine
* ask_cuisine{"cuisine": "Italian"}
    - slot{"cuisine": "Italian"}
    - action_validate_cuisine
    - slot{"cuisine": "Italian"}
    - utter_ask_budget
* ask_budget{"budget": "299"}
    - slot{"budget": "299"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "Yes"}
    - slot{"mailconfirmation": "Yes"}
    - action_decide_email
* ask_email{"email": "upgradchatbotassignment@gmail.com"}
    - slot{"email": "upgradchatbotassignment@gmail.com"}
    - action_send_email
    - reset_slots

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese", "location": "chandigarh"}
    - slot{"cuisine": "chinese"}
    - slot{"location": "chandigarh"}
    - action_check_city
    - slot{"location": "Chandigarh"}
    - action_validate_cuisine
    - slot{"cuisine": "Chinese"}
    - utter_ask_budget
* ask_budget{"budget": "299"}
    - slot{"budget": "299"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "no"}
    - slot{"mailconfirmation": "no"}
    - action_decide_email
    - slot{"email": null}
    - utter_goodbye
    - action_restart

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"location": "Varanasi"}
    - slot{"location": "Varanasi"}
    - action_check_city
    - slot{"location": "Varanasi"}
    - utter_ask_cuisine
* ask_cuisine{"cuisine": "french"}
    - slot{"cuisine": "french"}
    - action_validate_cuisine
    - slot{"cuisine": null}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "Italian"}
    - slot{"cuisine": "Italian"}
    - utter_ask_budget
* ask_budget{"budget": "700"}
    - slot{"budget": "700"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "No"}
    - slot{"mailconfirmation": "No"}
    - action_decide_email
    - reset_slots


## interactive_story_2
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* ask-location{"location": "bihar"}
    - slot{"location": "bihar"}
    - slot{"location": "bihar"}
    - action_check_city
    - slot{"location": null}
* restaurant_search{"location": "jammu"}
    - slot{"location": "jammu"}
    - action_check_city
    - slot{"location": "Jammu"}
    - utter_ask_cuisine
* ask_cuisine{"cuisine": " Mexican"}
    - slot{"cuisine": " Mexican"}
    - action_validate_cuisine
    - slot{"cuisine": "Mexican"}
    - utter_ask_budget
* ask_budget{"budget": "701"}
    - slot{"budget": "701"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "no"}
    - slot{"mailconfirmation": "no"}
    - utter_goodbye
    - action_restart

## interactive_story_1
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* ask-location{"\"entity\"": " \"location\", \"value\": \"mumbai\"", "location": "bombay"}
    - slot{"location": "bombay"}
    - action_check_city
    - slot{"location": "Bombay"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "South Indian"}
    - slot{"cuisine": "South Indian"}
    - action_check_city
    - slot{"location": "Bombay"}
    - action_validate_cuisine
    - slot{"cuisine": "South Indian"}
    - utter_ask_budget
* ask_budget{"budget": "701"}
    - slot{"budget": "701"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "Yes"}
    - slot{"mailconfirmation": "Yes"}
    - action_decide_email
* ask_email{"email": "abc@gmail.com"}
    - slot{"email": "abc@gmail.com"}
    - action_send_email
    - reset_slots
    - action_restart

## interactive_story_1
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* ask-location{"location": "amdavad"}
    - slot{"location": "amdavad"}
    - action_check_city
    - slot{"location": "Amdavad"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "south indian"}
    - slot{"cuisine": "south indian"}
    - action_validate_cuisine
    - slot{"cuisine": "South Indian"}
    - utter_ask_budget
* ask_budget{"budget": "700"}
    - slot{"budget": "700"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "No"}
    - slot{"mailconfirmation": "No"}
    - action_decide_email
    - reset_slots
    - action_restart

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"location": "Pune"}
    - slot{"location": "Pune"}
    - action_check_city
    - slot{"location": "Pune"}
    - utter_ask_cuisine
* ask_cuisine{"cuisine": "italian"}
    - slot{"cuisine": "italian"}
    - action_validate_cuisine
    - slot{"cuisine": "Italian"}
    - utter_ask_budget
* ask_budget{"budget": "400 to 900"}
    - slot{"budget": "400 to 900"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "No"}
    - slot{"mailconfirmation": "No"}
    - action_decide_email
    - reset_slots
    - action_restart


## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_validate_cuisine
    - slot{"cuisine": "Chinese"}
    - utter_ask_location
* ask-location{"location": "ajmer"}
    - slot{"location": "ajmer"}
    - action_check_city
    - slot{"location": "Ajmer"}
    - utter_ask_budget
* ask_budget{"budget": "1000"}
    - slot{"budget": "1000"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "yup"}
    - slot{"mailconfirmation": "yup"}
    - action_decide_email
* ask_email{"email": "abc@gmail.com"}
    - slot{"email": "abc@gmail.com"}
    - action_send_email
    - reset_slots
    - action_restart

## interactive_story_1
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* ask-location{"location": "bangkok"}
    - slot{"location": "bangkok"}
    - action_check_city
    - slot{"location": null}
* ask-location{"location": "manilla"}
    - slot{"location": "manilla"}
    - action_check_city
    - slot{"location": null}
* restaurant_search{"location": "mysore"}
    - slot{"location": "mysore"}
    - action_check_city
    - slot{"location": "Mysore"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "Italian"}
    - slot{"cuisine": "Italian"}
    - action_validate_cuisine
    - slot{"cuisine": "Italian"}
    - utter_ask_budget
* ask_budget{"budget": "500"}
    - slot{"budget": "500"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "No"}
    - slot{"mailconfirmation": "No"}
    - action_decide_email
    - reset_slots
    - action_restart

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_validate_cuisine
    - slot{"cuisine": "Chinese"}
    - utter_ask_location
* ask-location{"location": "kota"}
    - slot{"location": "kota"}
    - action_check_city
    - slot{"location": null}
* ask-location{"location": "colaba"}
    - slot{"location": "colaba"}
    - action_check_city
    - slot{"location": null}
* ask-location{"location": "hyderabad"}
    - slot{"location": "hyderabad"}
    - action_check_city
    - slot{"location": "Hyderabad"}
    - utter_ask_budget
* ask_budget{"budget": "<1000"}
    - slot{"budget": "<1000"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "Yes"}
    - slot{"mailconfirmation": "Yes"}
    - action_decide_email
* ask_email{"email": "ab@gmail.com"}
    - slot{"email": "ab@gmail.com"}
    - action_send_email
    - reset_slots
    - action_restart

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"location": "hyderabad"}
    - slot{"location": "hyderabad"}
    - action_check_city
    - slot{"location": "Hyderabad"}
    - utter_ask_cuisine
* ask_cuisine{"cuisine": "italian"}
    - slot{"cuisine": "italian"}
    - action_validate_cuisine
    - slot{"cuisine": "Italian"}
    - utter_ask_budget
* ask_budget{"budget": "200-1000"}
    - slot{"budget": "200-1000"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "nope"}
    - slot{"mailconfirmation": "nope"}
    - action_decide_email
    - reset_slots
    - action_restart

## interactive_story_1
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* ask-location{"location": "Delhi"}
    - slot{"location": "Delhi"}
    - action_check_city
    - slot{"location": "Delhi"}
    - utter_ask_cuisine
* ask_cuisine{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - action_validate_cuisine
    - slot{"cuisine": "North Indian"}
    - utter_ask_budget
* ask_budget{"budget": "500"}
    - slot{"budget": "500"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "No"}
    - slot{"mailconfirmation": "No"}
    - action_decide_email
    - reset_slots
    - action_restart

## interactive_story_1
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "kolkata"}
    - slot{"location": "kolkata"}
    - action_check_city
    - slot{"location": "Kolkata"}
    - utter_ask_cuisine
* ask_cuisine{"cuisine": " American"}
    - slot{"cuisine": " American"}
    - action_validate_cuisine
    - slot{"cuisine": "American"}
    - utter_ask_budget
* ask_budget{"budget": "701"}
    - slot{"budget": "701"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "No"}
    - slot{"mailconfirmation": "No"}
    - action_decide_email
    - reset_slots
    - action_restart

## interactive_story_2
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_validate_cuisine
    - slot{"cuisine": "Chinese"}
    - utter_ask_location
* restaurant_search{"location": "mumbai"}
    - slot{"location": "mumbai"}
    - action_check_city
    - slot{"location": "Mumbai"}
    - utter_ask_budget
* ask_budget{"budget": "1000"}
    - slot{"budget": "1000"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "No"}
    - slot{"mailconfirmation": "No"}
    - action_decide_email
    - reset_slots
    - action_restart

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"location": "Chennai"}
    - slot{"location": "Chennai"}
    - action_check_city
    - slot{"location": "Chennai"}
    - utter_ask_cuisine
* ask_cuisine{"cuisine": "south indian"}
    - slot{"cuisine": "south indian"}
    - action_validate_cuisine
    - slot{"cuisine": "South Indian"}
    - utter_ask_budget
* ask_budget{"budget": "1000"}
    - slot{"budget": "1000"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "No"}
    - slot{"mailconfirmation": "No"}
    - action_decide_email
    - reset_slots
    - action_restart

## interactive_story_2
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* ask-location{"location": "Chennai"}
    - slot{"location": "Chennai"}
    - action_check_city
    - slot{"location": "Chennai"}
    - utter_ask_cuisine
* ask_cuisine{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - action_validate_cuisine
    - slot{"cuisine": "North Indian"}
    - utter_ask_budget
* ask_budget{"budget": "1000"}
    - slot{"budget": "1000"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "Yes"}
    - slot{"mailconfirmation": "Yes"}
    - action_decide_email
* ask_email{"email": "nidhisnh7@gmail.com"}
    - slot{"email": "nidhisnh7@gmail.com"}
    - action_send_email
    - reset_slots
    - action_restart

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"location": "Ahmedabad"}
    - slot{"location": "Ahmedabad"}
    - action_check_city
    - slot{"location": "Ahmedabad"}
    - utter_ask_cuisine
* ask_cuisine{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_validate_cuisine
    - slot{"cuisine": "Chinese"}
    - utter_ask_budget
* ask_budget{"budget": "500"}
    - slot{"budget": "500"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "No"}
    - slot{"mailconfirmation": "No"}
    - action_decide_email
    - reset_slots
    - action_restart

## interactive_story_2
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* ask-location{"location": "Ahmedabad"}
    - slot{"location": "Ahmedabad"}
    - action_check_city
    - slot{"location": "Ahmedabad"}
    - utter_ask_cuisine
* ask_cuisine{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - action_validate_cuisine
    - slot{"cuisine": "North Indian"}
    - utter_ask_budget
* ask_budget{"budget": "600"}
    - slot{"budget": "600"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "No"}
    - slot{"mailconfirmation": "No"}
    - action_decide_email
    - reset_slots
    - action_restart

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_validate_cuisine
    - slot{"cuisine": "Chinese"}
    - utter_ask_location
* ask-location{"location": "Varanasi"}
    - slot{"location": "Varanasi"}
    - action_check_city
    - slot{"location": "Varanasi"}
    - utter_ask_budget
* ask_budget{"budget": "500"}
    - slot{"budget": "500"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "No"}
    - slot{"mailconfirmation": "No"}
    - action_decide_email
    - reset_slots
    - action_restart

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"cuisine": "italian"}
    - slot{"cuisine": "italian"}
    - action_validate_cuisine
    - slot{"cuisine": "Italian"}
    - action_validate_cuisine
    - slot{"cuisine": "Italian"}
    - utter_ask_location
* ask-location{"location": "Vasai-Virar City"}
    - slot{"location": "Vasai-Virar City"}
    - action_check_city
    - slot{"location": "Vasai-Virar City"}
    - utter_ask_budget
* ask_budget{"budget": "1000"}
    - slot{"budget": "1000"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "No"}
    - slot{"mailconfirmation": "No"}
    - action_decide_email
    - reset_slots
    - action_restart

## interactive_story_2
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* ask-location{"location": "Vasai-Virar City"}
    - slot{"location": "Vasai-Virar City"}
    - action_check_city
    - slot{"location": "Vasai-Virar City"}
    - utter_ask_cuisine
* ask_cuisine{"cuisine": "south indian"}
    - slot{"cuisine": "south indian"}
    - action_validate_cuisine
    - slot{"cuisine": "South Indian"}
    - utter_ask_budget
* ask_budget{"budget": "700"}
    - slot{"budget": "700"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "No"}
    - slot{"mailconfirmation": "No"}
    - action_decide_email
    - reset_slots
    - action_restart

## interactive_story_1
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* ask-location{"location": "Bokaro Steel City"}
    - slot{"location": "Bokaro Steel City"}
    - action_check_city
    - slot{"location": "Bokaro Steel City"}
    - utter_ask_cuisine
* ask_cuisine{"cuisine": " Mexican"}
    - slot{"cuisine": " Mexican"}
    - action_validate_cuisine
    - slot{"cuisine": "Mexican"}
    - utter_ask_budget
* ask_budget{"budget": "700"}
    - slot{"budget": "700"}
    - action_search_restaurants
    - utter_ask_mailconfirmation
* ask_mailconfirmation{"mailconfirmation": "No"}
    - slot{"mailconfirmation": "No"}
    - action_decide_email
    - reset_slots
    - action_restart
