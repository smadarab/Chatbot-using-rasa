## intent:affirm
- indeed
- that's right
- ok
- great
- right, thank you
- correct
- great choice
- sounds really good
- thanks
- sure

## intent:goodbye
- bye
- goodbye
- good bye
- stop
- end
- farewell
- Bye bye
- have a good one
- bye bye user

## intent:greet
- hey
- howdy
- hey there
- hello
- hi
- good morning
- good evening
- dear sir
- hii
- hola
- heyy

## intent:ask_cuisine
- [Chinese](cuisine)
- I would like [chinese](cuisine)
- I'll prefer [Chinese](cuisine)
- [American](cuisine)
- I would like [American](cuisine)
- I'll prefer [American](cuisine)
- [Italian](cuisine)
- I would like [Italian](cuisine)
- I'll prefer [Italian](cuisine)
- [North Indian](cuisine)
- I would like [North Indian]](cuisine)
- I'll prefer [North Indian]](cuisine)
- [South Indian](cuisine)
- I would like [South Indian](cuisine)
- I'll prefer [South Indian](cuisine)
- [Mexican](cuisine)
- I would like [Mexican](cuisine)
- I'll prefer [Mexican](cuisine)
- [American]{"entity": "cuisine", "value": " American"}
- [french](cuisine)
- [northindian](cuisine)
- [latin](askcuisine)
- [latin](cuisine)
- [thai](cuisine)
- [southafrican](cuisine)
- [north indian](cuisine)
- [southindian]{"entity": "cuisine", "value": " south indian"}
- [south asian](cuisine)
- [japanese](cuisine)
- [american]{"entity": "cuisine", "value": " American"}
- [Mexican]{"entity": "cuisine", "value": " Mexican"}
- i love [italian](cuisine)
- i would like to explore [italian](cuisine)
- [northindian]{"entity": "cuisine", "value": "north indian"}
- [south-indian]{"entity": "cuisine", "value": "south indian"}
- i love [chinese](cuisine)
- [mexican]{"entity": "cuisine", "value": " Mexican"}
- [spanish](cuisine)
- [spanish](cuisine)
- [Italian](cuisine)

## intent:ask-location
- In [Delhi](location)
- Near [Delhi](location)
- [Dilli]{"entity": "location", "value": "Delhi"}
- [New Dilli]{"entity": "location", "value": "Delhi"}
- -[New Delhi]{"entity": "location", "value": "Delhi"}
- [bangalore]{"entity": "location", "value": "bengaluru"}
- [calcutta](location)
- [bombay]{"entity": "location", "value": "Mumbai"}
- in [mubaim](location)
- [bihar](location)
- [amdavad](location)
- near [ajmer](location)
- [bangkok](location)
- [manilla](location)
- [kota](location)
- [colaba](location)
- [hyderabad](location)
- [bokaro]{"entity": "\"location\" ", "value": " \"Bokaro Steel City\""}
- [madras]{"entity": "location", "value": "Chennai"}
- [amdavad]{"entity": "location", "value": "Ahmedabad"}
- [banaras]{"entity": "location", "value": "Varanasi"}
- [vasaivirar]{"entity": "location", "value": "Vasai-Virar City"}
- [vasai-virar]{"entity": "location", "value": "Vasai-Virar City"}
- [bokaro]{"entity": "location", "value": "Bokaro Steel City"}
- [bokaro steel plant]{"entity": "location", "value": "Bokaro Steel City"}
- [nagarjuna sagar](location)
- [hubli-dharwad](location)
- [hubli-dharwad](location)
- [coimbatore](location)
- [krosur](location)
- [nasik]{"entity": "location", "value": "nashik"}
- [ongole](location)
- [miryalguda](location)
- [khammam](location)


## intent:restaurant_search
- [southindian]{"entity": "cuisine", "value": " south indian"}
- [Dilli]{"entity": "location", "value": "Delhi"}
- [New Dilli]{"entity": "location", "value": "Delhi"}
- [New Delhi]{"entity": "location", "value": "Delhi"}
- [bangalore]{"entity": "location", "value": "bengaluru"}
- [madras]{"entity": "location", "value": "Chennai"}
- [amdavad]{"entity": "location", "value": "Ahmedabad"}
- [banaras]{"entity": "location", "value": "Varanasi"}
- [vasaivirar]{"entity": "location", "value": "Vasai-Virar City"}
- [vasai-virar]{"entity": "location", "value": "Vasai-Virar City"}
- [bokaro]{"entity": "location", "value": "Bokaro Steel City"}
- [northindian]{"entity": "cuisine", "value": "north indian"}
- [south-indian]{"entity": "cuisine", "value": "south indian"}
- [Bokaro Steel City]{"entity": "location", "value": "Bokaro Steel City"}
- [BokaroSteelCity]{"entity": "location", "value": "Bokaro Steel City"}
- i'm looking for a place to eat
- I want to grab lunch
- I am searching for a dinner spot
- I am looking for some restaurants in [Delhi](location)
- I am looking for some restaurants in [Bangalore]{"entity": "location", "value": "bengaluru"}
- I am looking for some restaurants in [Hyderabad](location)
- I am looking for some restaurants in [Chennai](location)
- I am looking for some restaurants in [Bombay]{"entity": "location", "value": "Mumbai"}
- show me [chinese](cuisine) restaurants
- show me [chines]{"entity": "cuisine", "value": "chinese"} restaurants in the [New Delhi]{"entity": "location", "value": "Delhi"}
- show me [chines]{"entity": "cuisine", "value": "chinese"} restaurants in the [Chennai](location)
- show me a [mexican](cuisine) place in the [centre](location)
- i am looking for an [indian](cuisine) spot called olaolaolaolaolaola
- search for restaurants
- anywhere in the [west](location)
- I am looking for [asian fusion](cuisine) food
- I am looking a restaurant in [294328](location)
- in [Gurgaon](location)
- [South Indian](cuisine)
- [SouthIndian](cuisine)
- [North Indian](cuisine)
- [Italian](cuisine)
- [Chinese]{"entity": "cuisine", "value": "chinese"}
- [chinese](cuisine)
- [Lithuania](location)
- Oh, sorry, in [Italy](location)
- in [delhi](location)
- I am looking for some restaurants in [Mumbai](location)
- I am looking for [mexican indian fusion](cuisine)
- can you book a table in [rome](location) in a [moderate]{"entity": "price", "value": "mid"} price range with [british](cuisine) food for [four]{"entity": "people", "value": "4"} people
- [central](location) [indian](cuisine) restaurant
- please help me to find restaurants in [pune](location)
- Please find me a restaurantin [bangalore]{"entity": "location", "value": "bengaluru"}
- Please find me a restaurantin [Hyderabad](location)
- Please find me a restaurantin [Bombay]{"entity": "location", "value": "Mumbai"}
- Please find me a restaurantin [Chennai](location)
- [mumbai](location)
- show me restaurants
- please find me [chinese](cuisine) restaurant in [delhi](location)
- please find me [chinese](cuisine) restaurant in [Chennai](location)
- can you find me a [chinese](cuisine) restaurant
- [delhi](location)
- please find me a restaurant in [ahmedabad](location)
- please show me a few [italian](cuisine) restaurants in [bangalore]{"entity": "location", "value": "bengaluru"}
- please show me a few [italian](cuisine) restaurants in [Hyderabad](location)
- please show me a few [italian](cuisine) restaurants in [Chennai](location)
- [bangalore]{"entity": "location", "value": "bengaluru"}
- can you find me restaurant
- [Chennai](location)
- can you please find me a restaurant
- CAn you please find restaurant
- can you please find me a restaurent
- can you please find restaurant
- i am hungry
- i am hungry,find me a restaurant
- i am hungry find me a restaurant
- find me a restaurant
- find me restaurant
- find me a restaurant in [bangalore]{"entity": "location", "value": "bengaluru"} with [chinese](cuisine)
- i am hungry.looking out for some good [chinese](cuisine) restaurants in [bangalore]{"entity": "location", "value": "bengaluru"}
- can you suggest me some good [chinese](cuisine) restaurants in [bangalore]{"entity": "location", "value": "bengaluru"}
- finfd me some [chinese](cuisine) restaurant in [bangalore]{"entity": "location", "value": "bengaluru"}
- get me some [chinese](cuisine) to eat in [bangalore]{"entity": "location", "value": "bengaluru"}
- find me a [chinese](cuisine) restaurant
- find me a [chinese](cuisine) restaurant in [delhi](location)
- find me [chinese](cuisine) restaurant in [delhi](location)
- i am hungry.looking out for some good restaurants
- [bengaluru](location)
- i will prefer [chinese](cuisine)
- can you suggest me some good restaurants in [rishikesh](location)
- i am hungry looking out for some restaurants
- [bengaluru]{"entity": "location", "value": "bangalore"}
- can you suggest some good restaurants in [kolkata](location)
- i am hungry looking out for some [chinese](cuisine) restaurants in [bangalore]{"entity": "location", "value": "bengaluru"}
- find me restaurants in [delhi](location) with [chinese](cuisine) cuisine
- find me a restaurant in [delhi](location) in [chinese](cuisine)
- find me [chinese](cuisine) restaurant in [bombay]{"entity": "location", "value": "Mumbai"}
- find me [chinese](cuisine) restaurant in [hongkong](location)
- find me a [italian](cuisine) restaurant in [hyderabad](location)
- find me a restaurant in [delhi](location)
- [chinese](cuisine) [bangalore]{"entity": "location", "value": "bengaluru"}
- find me a [chinese](cuisine) restuarant in [delhi](location)
- find me [chinese](cuisine) restaurant in [bangalore]{"entity": "location", "value": "bengaluru"}
- find me restaurant in [delhi](location) [chinese](cuisine) one
- find a restaurant in [delhi](location) with [chinese](cuisine)
- find me a [south indian](cuisine) restaurant in [delhi](location)
- find me a [southindian](cuisine) restaurant in [delhi](location)
- find me a restuarant
- [Varanasi](location)
- [Delhi](location)
- find a [chinese](cuisine) restuarant in [patna](location)
- [chinese](cuisine) restuarant in [delhi](location)
- [calcutta]{"entity": "location", "value": "kolkata"}
- [bombay]{"entity": "location", "value": "mumbai"}
- i am hungry looking out for some good restaurants
- i will prefer [italian](cuisine)
- can you suggest some good restaurant in [rishikesh](location)
- ok.show me some in [allahabad](location)
- [chennai](location)
- i will prefer [chines]{"entity": "cuisine", "value": "chinese"}
- [mumbai]{"entity": "location", "value": "Mumbai"}
- i am hungry looking out for some [chinese](cuisine) restaurants in [chandigarh](location)
- can you suggest some good restuarant in [Varanasi](location)
- suggest some good place to eat
- [jammu](location)
- looking for a place to eat
- [south indian](cuisine)
- [southindian](cuisine)
- looking for eating place in [Pune](location)
- looking for a [chinese](cuisine) restuarant nearby
- looking for restuarant
- [mysore](location)
- [chinese](cuisine) place near me
- i am looking for a good dinner place in [hyderabad](location)
- looking for a good restuarant
- suggest good eating place
- good [chinese](cuisine) restuarant
- looking for a good eating place in [Madras]{"entity": "location", "value": "Chennai"}
- looking  for an eating place
- looking for restuarant in [amdavad]{"entity": "location", "value": "Ahmedabad"}
- searching for a good [chinese](cuisine) restuarant
- looking for place to have [italian](cuisine) food
- good place for lunch
- looking for a restuarant
- looking for some good restaurants in [bilaspur](location)
- looking for restaurants in [bijapur](location)
- find me restaurant in [jaipur](location)
- find me good restaruants in [cuttack](location)
- will be looking for [400 and 900](budget) range
-  find me [spanish](cuisine) restaurant in [bengaluru](location)

## intent:ask_email
- can u mail me the information to [abc@abc.com](email)?
- can u mail to [test@tes.com](email)?
- can u mail me at [test-123.456@dom.123.co.in](email)?
- email address - [test.some@gmail.co.in](email). Mail this list.
- email me at [email-123@domina.com](email)
- mail me [emial@domain.io](email)
- my email address [email.123-abc@domain.123.com](email)
- please mail me the list to [123-email@domain.co.in](email)
- please send me the list to [123@domain.net](email)
- please send this to [email.123@123.456.com](email)
- send this to [abc-email@abc.com](email)
- send to [abc_123-email@abc123.com](email)
- this is my email address - [email-abc_123@abc.com.edu](email). send me an email.
- [email1_34-ret@host-name.123.com](email)
- [hi@gmail.com](email)
- send email to [texttext2525@gmail.com](email)
- [textext2525@gmail.com](email)
- [m.satyanarayana111@gmail.com](email)
- [texttext2525@gmail.com](email)
- [upgradchatbotassignment@gmail.com](email)
- send them to [upgradchatbotassignment@gmail.com](email)
- [upgradchatbotassingment@gmail.com](email)
- [nidhisnh7@gmail.com](email)
- [hi.com](email)
- [grenigneriu.com](email)
- [me.com](email)
- [abc@gmail.com](email)
- [ab@gmail.com](email)
- its [upgradchatbotassignment@gmail.com](email)
- [ifweif.com](email)
- [feirfi.com](email)
- [fwefwh.com](email)
- [oifnewon.com](email)
- [fwefwe.com](email)
- [wfewfe.com](email)
- [fwiefweif.com](email)
- send to [upgradchatbotassignment@gmail.com](email)
- [fnwefnew.com](email)
- [uwefwe.com](email)
- [upgradchatbotassignment@gmail.com](email)

## intent:ask_budget
- I want to eat at a place between 300 and 700
- I am fine with an expensive place
- I am looking for a dinner place at less than 300
- budget
- [300 to 700](budget)
- [<300]{"entity": "budget", "value": "300"}
- [<300](budget)
- [>700](budget)
- in between[ 300 to 700]{"entity": "budget", "value": "300 to 700"}
- some where from [400 to 500](budget) range
- between [200 to 900](budget) range
- between [400 to 600](budget)
- [500 to 700](budget) range
- somewhere around [500 to 800](budget)
- [300-700](budget)
- [440 - 650](budget)
- [700-800](budget)
- [300-700](budget) range
- [>700]{"entity": "budget", "value": "700"}
- [400 to 900](budget)
- any place below [1000](budget)
- < [500](budget)
- [<1000](budget)
- [200-1000](budget)
- [500](budget)
- not more than [1000](budget)
- [1000](budget) for two
- around [1000](budget) for two
- not more than [500](budget)
- [600](budget)
- upto [500](budget)
- [1000](budget)
- well i have [1000](budget)
- my pockets are nill,find something below [100](budget)
- some where around [600 - 900](budget)
- inbetween [800 and 900](budget)
- [300,400](budget)
- more then [300](budget)
- [800](budget) range
- [900](budget) above

## intent:stop
- thank you
- thank you and bye
- thak you

## intent:ask_mailconfirmation
- [please](mailconfirmation) send them to [upgradchatbotassignment@gmail.com](email)
- [please](mailconfirmation) send it to [upgradchatbotassignment@gmail.com](email)
- [allright](mailconfirmation) send it to [upgradchatbotassingment@gmail.com](email)
- [offcourse](mailconfirmation) please send them to [upgradchatbotassignment@gmial.com](email)
- [yup](budget)
- [please](mailconfirmation) send them
- [Yes](mailconfirmation) please send to [upgradchatbotassignment@gmail.com](email)
- [No](mailconfirmation) dont send
- [Yes](mailconfirmation) please
- [No](mailconfirmation) i dont want
- [Yupp](mailconfirmation) i want top 10 restaurants to be mailed
- [yes](mailconfirmation) please
- [yes](mailconfirmation) please send it to [upgradchatbot@gmail.com](email)
- [yeah](mailconfirmation) send it to [upgradchatbotassignment@gmail.com](email)
- [yes](mailconfirmation) please send it to [upgrad]{"entity": "mail", "value": "upgradchatbotassignment@gmail.com"}
- [Yup](mailconfirmation) mail me
- [all right](mailconfirmation) mail me on [upgradchatbot@gmail.com](email)
- [No](mailconfirmation) not required
- [yes](mailconfirmation) please send it to [upgradchatbotassignment@gmail.com](email)
- [No](mailconfirmation)
- [please](mailconfirmation)
- [allright](mailconfirmation)
- [send](mailconfirmation)me
- [yes](mailconfirmation),please sent it to [upgradchatbotassingment@gmail.com](email)
- [yes](mailconfirmation).please send it to [upgradchatbotassignment@gmail.com](email)
- [no](mailconfirmation) thanks
- [no](mailconfirmation)
- [yup](mailconfirmation)
- [nope](mailconfirmation)
- i [dont](mailconfirmation) want
- [aye aye](mailconfirmation)
- [allright](mailconfirmation) send them to [upgradchatbotassignment@gmail.com](email)
- hmm [send](mailconfirmation) it to [fiwefw.com](email)
- [send](mailconfirmation) them
- [sure](mailconfirmation)
- hmm [send](mailconfirmation) them to [upgradchatbotassignment@gmail.com](email)

## synonym: "Bokaro Steel City"
- bokaro

## synonym: American
- American
- american
- english

## synonym: Mexican
- Mexican
- mexican

## synonym:300
- <300
- 0,300
- less then 300

## synonym:300 to 700
-  300 to 700
- 300 to 700
- between 300 to 500
- 300-700
- 400-600
- 300,700

## synonym:4
- four

## synonym:700
- >700
- more then 700
- geater then 700

## synonym:Ahmedabad
- amdavad

## synonym:Chennai
- madras
- Madras

## synonym:Delhi
- Dilli
- New Dilli
- New Delhi

## synonym:nashik
- nasik

## synonym:Mumbai
- Bombay
- mumbai

## synonym:Varanasi
- banaras
- Benaras

## synonym:Vasai-Virar City
- vasaivirar
- vasai-virar

## synonym:bangalore
- bengaluru

## synonym:bengaluru
- bangalore
- Bangalore

## synonym:chinese
- chines
- Chinese
- Chines

## synonym:kolkata
- calcutta

## synonym:mid
- moderate

## synonym:mumbai
- bombay

## synonym:north indian
- northindian

## synonym:south indian
- south-indian
- southindian

## synonym:upgradchatbotassignment@gmail.com
- upgrad

## synonym:vegetarian
- veggie
- vegg

## regex:email
- ([\w\.-]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)

## regex:greet
- hey[^\s]*

## regex:pincode
- [0-9]{6}

## lookup:cuisine
- South Indian
- North Indian
- Mexican
- American
- Italian
- Chinese

## lookup:location
  data/cities/cities.txt
